package com.ultron.jarvis;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout messages;
    EditText input;

    TextView tv(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size);
        t.setPadding(18,12,18,12); return t;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(22,22,22,14);
        root.setBackgroundColor(Color.rgb(3,7,18));
        TextView title = tv("J A R V I S", 26); title.setTextColor(Color.rgb(80,190,255)); root.addView(title);
        TextView online = tv("● ONLINE  •  READY", 12); online.setTextColor(Color.rgb(70,230,180)); root.addView(online);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        ScrollView scroll = new ScrollView(this); scroll.addView(messages); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        LinearLayout bar = new LinearLayout(this);
        input = new EditText(this); input.setHint("Ask JARVIS..."); input.setHintTextColor(Color.GRAY); input.setTextColor(Color.WHITE); input.setSingleLine(true);
        bar.addView(input, new LinearLayout.LayoutParams(0,60,1));
        Button send = new Button(this); send.setText("SEND"); send.setTextColor(Color.rgb(80,190,255)); send.setOnClickListener(v -> ask());
        bar.addView(send, new LinearLayout.LayoutParams(120,60)); root.addView(bar); setContentView(root);
        add("JARVIS", "Hello. I am JARVIS. Ask me anything.");
    }

    void add(String who, String msg) {
        TextView t = tv(who + "\n" + msg, 15); t.setBackgroundColor(Color.rgb(10,20,38));
        messages.addView(t, new LinearLayout.LayoutParams(-1,-2));
    }
    void ask() {
        String q=input.getText().toString().trim(); if(q.isEmpty()) return;
        add("YOU", q); input.setText("");
        add("JARVIS", "Command received. Configure your AI provider/API separately to enable live AI responses.");
    }
}
