# JARVIS Android

GitHub-ready Android project. Push to GitHub and run the **Build JARVIS APK** workflow.
The workflow produces an artifact named `JARVIS.apk`.

No API key is bundled in the project.
